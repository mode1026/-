# -*- coding: utf-8 -*-
"""
自动打字脚本 v8.1
  修复: ASCII 也用 PostMessage WM_CHAR（与中文一致），学习通可用
  窗口不隐藏，全程可见
"""
import time, threading, ctypes
from ctypes import wintypes
import tkinter as tk
from tkinter import messagebox

COUNTDOWN = 5
CHAR_DELAY = 0.025

user32 = ctypes.windll.user32

def post_msg(hwnd, msg, wp, lp=0):
    user32.PostMessageW(hwnd, msg, wp, lp)

def post_char(hwnd, ch):
    """发送 WM_CHAR — 学习通等平台不拦截消息直投"""
    post_msg(hwnd, 0x0102, ord(ch), 0)

def post_enter(hwnd):
    post_msg(hwnd, 0x0100, 0x0D, 0x1C0001)
    post_msg(hwnd, 0x0102, 0x0D, 0)
    post_msg(hwnd, 0x0101, 0x0D, 0xC01C0001)

def post_tab(hwnd):
    post_msg(hwnd, 0x0100, 0x09, 0x0F0001)
    post_msg(hwnd, 0x0102, 0x09, 0)
    post_msg(hwnd, 0x0101, 0x09, 0xC00F0001)

def do_paste_all(text):
    import pyperclip
    try: o = pyperclip.paste()
    except: o = ""
    pyperclip.copy(text); time.sleep(0.15)
    IK, KFU = 1, 0x0002
    class KBI(ctypes.Structure):
        _fields_ = [("wVk",wintypes.WORD),("wScan",wintypes.WORD),
                    ("dwFlags",wintypes.DWORD),("time",wintypes.DWORD),
                    ("dwExtraInfo",ctypes.POINTER(ctypes.c_ulong))]
    class INP(ctypes.Structure):
        class U(ctypes.Union):
            _fields_=[("ki",KBI),("_pad",ctypes.c_char*24)]
        _anonymous_=("_u",)
        _fields_=[("type",wintypes.DWORD),("_u",U)]
    def _si(*xs):
        arr=(INP*len(xs))(*xs)
        user32.SendInput(len(xs),ctypes.byref(arr),ctypes.sizeof(INP))
    d_c=INP();d_c.type=IK;d_c.ki.wVk=0x11
    d_v=INP();d_v.type=IK;d_v.ki.wVk=0x56
    u_v=INP();u_v.type=IK;u_v.ki.wVk=0x56;u_v.ki.dwFlags=KFU
    u_c=INP();u_c.type=IK;u_c.ki.wVk=0x11;u_c.ki.dwFlags=KFU
    _si(d_c,d_v,u_v,u_c)
    time.sleep(0.15)
    try: pyperclip.copy(o)
    except: pass

def type_text(text, cb):
    """
    全部字符都用 PostMessage 直投目标窗口
    WM_CHAR 消息不会被输入钩子拦截
    """
    total = len(text)
    # 循环中刷新 hwnd（有些应用会动态切换子窗口）
    hwnd = user32.GetForegroundWindow()
    if not hwnd:
        return

    for i, ch in enumerate(text):
        if i % 100 == 0:
            # 定期刷新目标窗口句柄
            hwnd = user32.GetForegroundWindow()

        if ch == '\n':
            post_enter(hwnd)
        elif ch == '\r':
            pass
        elif ch == '\t':
            post_tab(hwnd)
        else:
            # 所有字符统一 PostMessage WM_CHAR
            post_char(hwnd, ch)

        time.sleep(CHAR_DELAY)
        if cb:
            cb(i + 1, total, ch)


# ==================== GUI ====================

class App:
    def __init__(self, root):
        self.root = root
        self.root.title("自动打字 v8.1")
        self.root.configure(bg="#f0f0f0")
        self.root.minsize(350, 300)

        sh = root.winfo_screenheight()
        sw = root.winfo_screenwidth()
        w = min(480, sw - 40)
        h = min(420, sh - 80)
        self.root.geometry(f"{w}x{h}+{(sw-w)//2}+{(sh-h)//2-20}")

        try: root.attributes('-topmost', True)
        except: pass

        self.mode = tk.StringVar(value="unicode")
        self._build()
        root.protocol("WM_DELETE_WINDOW", root.destroy)

    def _build(self):
        bg = "#f0f0f0"
        f9 = ("Microsoft YaHei", 9)
        f8 = ("Microsoft YaHei", 8)
        fb = ("Microsoft YaHei", 11, "bold")

        # --- 底部 ---
        bf = tk.Frame(self.root, bg=bg, height=32)
        bf.pack(side=tk.BOTTOM, fill=tk.X, padx=6, pady=(2, 6))
        bf.pack_propagate(False)
        self.cd = tk.Label(bf, text="就绪", font=f9, fg="gray", bg=bg, width=12, anchor=tk.W)
        self.cd.pack(side=tk.LEFT)
        self.st = tk.Label(bf, text="", font=f8, bg=bg, fg="#666")
        self.st.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4)
        tk.Button(bf, text="清空", font=f9, width=4, relief=tk.RAISED,
                  bg="#fafafa", command=self._clr).pack(side=tk.RIGHT, padx=2)
        self.bt = tk.Button(bf, text="▶ 开始", font=("Microsoft YaHei", 10, "bold"),
                            width=7, relief=tk.RAISED, bg="#43A047", fg="white",
                            activebackground="#388E3C", activeforeground="white",
                            command=self._go)
        self.bt.pack(side=tk.RIGHT, padx=2)

        # --- 进度 ---
        pf = tk.Frame(self.root, bg=bg, height=36)
        pf.pack(side=tk.BOTTOM, fill=tk.X, padx=6, pady=0)
        pf.pack_propagate(False)
        self.pcv = tk.Canvas(pf, height=4, bg="#ddd", highlightthickness=0)
        self.pcv.pack(fill=tk.X)
        self.pr = 0
        self.char = tk.Label(pf, text="", font=("Consolas", 12, "bold"),
                             fg="#1976D2", bg=bg, anchor="center")
        self.char.pack(fill=tk.X)
        pf.bind("<Configure>", self._drawp)

        # --- 文本框 ---
        tf = tk.Frame(self.root, bg=bg)
        tf.pack(fill=tk.BOTH, expand=True, padx=6, pady=2)
        self.ta = tk.Text(tf, font=("Microsoft YaHei", 10), wrap=tk.WORD,
                          undo=True, relief=tk.SOLID, borderwidth=1, padx=5, pady=3)
        sb = tk.Scrollbar(tf, orient=tk.VERTICAL, command=self.ta.yview)
        self.ta.configure(yscrollcommand=sb.set)
        self.ta.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        sb.pack(side=tk.RIGHT, fill=tk.Y)
        self._ph = "在此粘贴要自动输入的内容…"
        self.ta.insert("1.0", self._ph); self.ta.configure(fg="#aaa")
        self.ta.bind("<FocusIn>", self._fi)
        self.ta.bind("<FocusOut>", self._fo)
        self.ta.bind("<Control-v>", lambda e: self.root.after(5, self._ap))
        self.ta.bind("<Control-V>", lambda e: self.root.after(5, self._ap))

        # --- 模式 ---
        mf = tk.LabelFrame(self.root, text="模式", font=f8, bg=bg, padx=6, pady=2)
        mf.pack(fill=tk.X, padx=6, pady=(2, 1))
        tk.Radiobutton(mf, text="🚀粘贴(Ctrl+V)", variable=self.mode,
                       value="paste", font=f9, bg=bg, activebackground=bg).pack(side=tk.LEFT)
        tk.Radiobutton(mf, text="🔤逐字注入(防检测)", variable=self.mode,
                       value="unicode", font=f9, bg=bg, activebackground=bg).pack(side=tk.LEFT, padx=8)

        # --- 标题 ---
        hdr = tk.Frame(self.root, bg=bg)
        hdr.pack(fill=tk.X, padx=6, pady=(4, 0))
        tk.Label(hdr, text="📝 自动打字", font=fb, bg=bg).pack(side=tk.LEFT)
        self.pin = tk.BooleanVar(value=True)
        tk.Checkbutton(hdr, text="📌置顶", variable=self.pin,
                       command=lambda: self.root.attributes('-topmost', self.pin.get()),
                       font=f8, bg=bg, activebackground=bg, indicatoron=False,
                       selectcolor="#b3d9ff", padx=5, relief=tk.GROOVE).pack(side=tk.RIGHT)

        # --- 提示 ---
        tip = tk.Frame(self.root, bg="#e8f4fd")
        tip.pack(fill=tk.X, padx=6, pady=(2, 0))
        tk.Label(tip, text="💡 粘贴内容 → 选模式 → ▶开始 → 倒计时结束前点击目标输入框",
                 font=f8, fg="#0D47A1", bg="#e8f4fd", padx=4, pady=2).pack(anchor=tk.W)

    def _fi(self, e=None):
        if self.ta.get("1.0", "end-1c") == self._ph:
            self.ta.delete("1.0", tk.END); self.ta.configure(fg="black")

    def _fo(self, e=None):
        if not self.ta.get("1.0", "end-1c").strip():
            self.ta.insert("1.0", self._ph); self.ta.configure(fg="#aaa")

    def _ap(self):
        c = self.ta.get("1.0", "end-1c")
        if self._ph in c:
            self.ta.delete("1.0", tk.END)
            self.ta.insert("1.0", c.replace(self._ph, ""))
            self.ta.configure(fg="black")

    def _clr(self):
        self.ta.delete("1.0", tk.END); self.ta.focus_set()

    def _drawp(self, e=None):
        self.pcv.delete("bar")
        w, h = self.pcv.winfo_width(), self.pcv.winfo_height()
        pw = int(w * self.pr) if w > 0 and self.pr > 0 else 0
        if pw > 0 and h > 0:
            self.pcv.create_rectangle(0, 0, pw, h, fill="#4CAF50", outline="", tags="bar")

    def _sp(self, r): self.pr = r; self._drawp()

    def _sc(self, ch):
        d = {'\n': "↵", '\t': "→", ' ': "␣", '\r': ""}.get(ch, ch)
        self.char.configure(text=d)

    def _go(self):
        t = self.ta.get("1.0", "end-1c")
        if t == self._ph: t = ""
        t = t.rstrip('\n\r')
        if not t.strip():
            messagebox.showwarning("提示", "请先粘贴内容！"); return
        mode = self.mode.get()
        self.bt.configure(state="disabled", text="⏳", bg="#9e9e9e")
        self.st.configure(text="", fg="black"); self._sp(0); self.char.configure(text="")
        threading.Thread(target=self._run, args=(t, mode), daemon=True).start()

    def _run(self, text, mode):
        for i in range(COUNTDOWN, 0, -1):
            self.root.after(0, lambda s=i: self.cd.configure(
                text=f"⏳ {s}秒后开始，点目标框！",
                fg="red" if s <= 3 else "#FF9800"))
            time.sleep(1)
        self.root.after(0, self.cd.configure, {"text": "输入中…", "fg": "#1976D2"})
        self.root.after(0, self.st.configure, {"text": "⚠️ 勿动键盘鼠标", "fg": "#1976D2"})

        # 隐藏窗口让目标获得焦点
        self.root.after(0, self.root.withdraw)
        time.sleep(0.7)

        if mode == "paste":
            do_paste_all(text)
            self._finish(True, "✅ 粘贴完成"); return

        def cb(c, t, ch):
            self.root.after(0, self._sp, c/t if t else 1)
            self.root.after(0, self._sc, ch)
            self.root.after(0, self.st.configure, {"text": f"{c}/{t}", "fg": "#555"})

        try:
            type_text(text, cb)
            self._finish(True, "✅ 输入完成")
        except Exception as e:
            self._finish(False, f"❌ {e}")

    def _finish(self, ok, msg):
        c = "#388E3C" if ok else "#D32F2F"
        self.root.after(0, self.root.deiconify)
        self.root.after(50, lambda: self.root.attributes('-topmost', True))
        self.root.after(300, lambda: self.root.attributes('-topmost', self.pin.get()))
        self.root.after(0, self.st.configure, {"text": msg, "fg": c})
        self.root.after(0, self.cd.configure, {"text": "就绪", "fg": "gray"})
        self.root.after(0, self._sp, 0)
        self.root.after(0, lambda: self.char.configure(text=""))
        self.root.after(0, lambda: self.bt.configure(state="normal", text="▶ 开始", bg="#43A047"))


def main():
    root = tk.Tk()
    App(root)
    root.mainloop()

if __name__ == "__main__":
    main()
