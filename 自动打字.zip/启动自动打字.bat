@echo off
cd /d "%~dp0"
start "" pythonw auto_type.pyw
